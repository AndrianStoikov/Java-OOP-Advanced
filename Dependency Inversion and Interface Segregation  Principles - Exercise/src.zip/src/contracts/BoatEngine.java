package contracts;

public interface BoatEngine extends IModelable {
    int getOutput();
}
