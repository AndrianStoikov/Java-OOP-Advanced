package contracts;

public interface Speedable {
    double getSpeed(IRace race);
}
