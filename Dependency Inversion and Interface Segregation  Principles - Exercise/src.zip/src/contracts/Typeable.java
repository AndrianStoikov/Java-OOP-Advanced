package contracts;

/**
 * Created by Andrian on 10.4.2017 г..
 */
public interface Typeable {
    String getType();
}
