package contracts;

import java.io.IOException;

/**
 * Created by Andrian on 9.4.2017 г..
 */
public interface Runable {
    void run() throws IOException;
}
