package exceptions;

/**
 * Created by Andrian on 10.4.2017 г..
 */
public class ArgumentException extends Exception {
    public ArgumentException(String message) {
        super(message);
    }
}
