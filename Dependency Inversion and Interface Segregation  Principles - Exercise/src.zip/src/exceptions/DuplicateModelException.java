package exceptions;

public class DuplicateModelException extends Exception {
    public DuplicateModelException(String message) {
        super(message);
    }

}
