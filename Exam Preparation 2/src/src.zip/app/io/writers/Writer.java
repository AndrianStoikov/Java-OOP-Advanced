package app.io.writers;

/**
 * Created by Andrian on 20.4.2017 г..
 */
@SuppressWarnings("DefaultFileTemplate")
public interface Writer {
    void writeLn(String string);
}
