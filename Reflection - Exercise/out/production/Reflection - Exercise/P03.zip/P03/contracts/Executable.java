package P03.contracts;

public interface Executable {

	String execute();

}
