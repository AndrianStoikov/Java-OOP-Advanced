package P03;

import P03.contracts.Repository;
import P03.contracts.UnitFactory;
import P03.core.Engine;
import P03.core.factories.UnitFactoryImpl;
import P03.data.UnitRepository;

public class Main {
    public static void main(String[] args) {
        Repository repository = new UnitRepository();
        UnitFactory factory = new UnitFactoryImpl();
        Engine engine = new Engine(repository, factory);
        engine.run();
    }
}
