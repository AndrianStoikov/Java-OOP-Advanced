package P03.contracts;

public interface Unit extends Destroyable, Attacker {
}
