package P03.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
