package P03.contracts;

public interface Runnable {
	void run();
}
