package P04_WorkForce.writers;

/**
 * Created by Andrian on 13.4.2017 г..
 */
@SuppressWarnings("DefaultFileTemplate")
public interface Writer {
    void printLn(String message);
}
