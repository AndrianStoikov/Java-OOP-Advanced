package P04_WorkForce.contracts;

/**
 * Created by Andrian on 13.4.2017 г..
 */
@SuppressWarnings("DefaultFileTemplate")
public interface Nameable {
    String getName();
}
