package utils;

/**
 * Created by Andrian on 19.4.2017 г..
 */
@SuppressWarnings("DefaultFileTemplate")
public interface RegistrationTime {
    @Override
    String toString();
}
