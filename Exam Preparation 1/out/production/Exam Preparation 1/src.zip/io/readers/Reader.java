package io.readers;

import java.io.IOException;

/**
 * Created by Andrian on 18.4.2017 г..
 */
@SuppressWarnings("DefaultFileTemplate")
public interface Reader {
    String read() throws IOException;
}
