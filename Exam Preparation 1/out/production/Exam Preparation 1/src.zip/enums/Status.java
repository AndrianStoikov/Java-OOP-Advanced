package enums;

/**
 * Created by Andrian on 19.4.2017 г..
 */
@SuppressWarnings("DefaultFileTemplate")
public enum Status {
    SPECIAL,
    NON_SPECIAL
}
