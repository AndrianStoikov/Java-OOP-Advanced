package enums;

public enum EmergencyLevel {
    Minor,
    Major,
    Disaster
}
