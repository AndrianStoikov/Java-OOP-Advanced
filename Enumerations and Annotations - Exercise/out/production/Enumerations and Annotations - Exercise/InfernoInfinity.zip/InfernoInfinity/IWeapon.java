package InfernoInfinity;

import InfernoInfinity.Gems.Socket;

public interface IWeapon {
    void addGem(int index, Socket type);

    void removeGem(int index);
}
