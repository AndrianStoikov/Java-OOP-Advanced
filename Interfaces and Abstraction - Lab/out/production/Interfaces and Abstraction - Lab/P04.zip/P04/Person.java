package P04;

/**
 * Created by Andrian on 15.3.2017 г..
 */
public interface Person {
    String getName();

    String sayHello();
}
