package P10;

/**
 * Created by Andrian on 16.3.2017 г..
 */
public class Archangel extends Character implements GameCharacter {
    private int specialPoints;

    protected Archangel(String username, Integer level, int specialPoints) {
        super(username, level);
        this.specialPoints = specialPoints;
    }

    @Override
    public String getHashedPassword() {
        StringBuilder sb = new StringBuilder(super.getUserName());
        sb.reverse();
        sb.append(super.getUserName().length() * 21);
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("\"%s\" | \"%s\" -> %s", this.getUserName(),
                this.getHashedPassword(), this.getClass().getSimpleName()));
        sb.append(System.lineSeparator());

        sb.append(String.format("%d", this.getLevel() * this.specialPoints));
        return sb.toString();
    }
}
