package P10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader Console = new BufferedReader(new InputStreamReader(System.in));

        String[] cmdArgs = Console.readLine().split(" \\| ");

        GameCharacter character = createCharacter(cmdArgs);
        System.out.println(character);
    }

    private static GameCharacter createCharacter(String[] cmdArgs) {
        switch (cmdArgs[1]) {
            case "Archangel": {
                String name = cmdArgs[0];
                int mana = Integer.parseInt(cmdArgs[2]);
                int level = Integer.parseInt(cmdArgs[3]);
                return new Archangel(name, level, mana);
            }
            case "Demon": {
                String name = cmdArgs[0];
                double energy = Integer.parseInt(cmdArgs[2]);
                int level = Integer.parseInt(cmdArgs[3]);
                return new Demon(name, level, energy);
            }
        }
        return null;
    }
}
