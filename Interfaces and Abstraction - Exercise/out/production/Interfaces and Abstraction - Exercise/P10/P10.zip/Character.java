package P10;

public abstract class Character implements GameCharacter{
    private String username;
    private Integer level;

    protected Character(String username, Integer level) {
        this.username = username;
        this.level = level;
    }

    protected String getUserName() {
        return this.username;
    }

    protected Integer getLevel() {
        return this.level;
    }
}
