package P10;

public class Demon extends Character implements GameCharacter{
    private Double specialPoints;

    protected Demon(String username, Integer level, Double specialPoints) {
        super(username, level);
        this.specialPoints = specialPoints;
    }

    @Override
    public String getHashedPassword() {
        return (super.getUserName().length() * 217) + "";
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("\"%s\" | \"%s\" -> %s", this.getUserName(),
                this.getHashedPassword(), this.getClass().getSimpleName()));
        sb.append(System.lineSeparator());

        sb.append(String.format("%.1f", this.getLevel() * this.specialPoints));
        return sb.toString();
    }
}
