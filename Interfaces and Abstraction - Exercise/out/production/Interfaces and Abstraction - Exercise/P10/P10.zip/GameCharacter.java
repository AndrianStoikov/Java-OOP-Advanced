package P10;

/**
 * Created by Andrian on 16.3.2017 г..
 */
public interface GameCharacter {
    String getHashedPassword();
}
