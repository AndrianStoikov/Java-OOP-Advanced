package P08.Soldiers.Spies;

import P08.Soldiers.ISoldier;
import P08.Soldiers.Soldier;

public class Spy extends Soldier implements ISoldier {
    private int codeNumber;

    public Spy(String id, String firstName, String lastName, int codeNumber) {
        super(id, firstName, lastName);
        this.codeNumber = codeNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(System.lineSeparator());
        sb.append("Code Number: ").append(this.codeNumber);

        return sb.toString();
    }
}
