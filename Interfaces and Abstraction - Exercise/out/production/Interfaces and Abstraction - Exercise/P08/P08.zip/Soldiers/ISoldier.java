package P08.Soldiers;

public interface ISoldier {
    String getID();

    String getFirstName();

    String getLastName();
}
