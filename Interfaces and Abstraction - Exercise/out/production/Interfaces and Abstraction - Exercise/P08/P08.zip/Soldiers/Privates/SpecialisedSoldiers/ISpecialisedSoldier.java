package P08.Soldiers.Privates.SpecialisedSoldiers;

import P08.Soldiers.ISoldier;
import P08.Soldiers.Privates.IPrivate;

public interface ISpecialisedSoldier extends IPrivate, ISoldier {
}
