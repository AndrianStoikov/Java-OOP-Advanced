package P08.Soldiers.Privates;

import P08.Soldiers.ISoldier;

public interface IPrivate extends ISoldier {
    Double getSalary();
}
