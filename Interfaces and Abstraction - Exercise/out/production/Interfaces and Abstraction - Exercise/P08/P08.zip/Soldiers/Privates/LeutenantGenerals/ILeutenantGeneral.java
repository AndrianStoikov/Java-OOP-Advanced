package P08.Soldiers.Privates.LeutenantGenerals;

import P08.Soldiers.ISoldier;
import P08.Soldiers.Privates.IPrivate;
import P08.Soldiers.Privates.Private;

public interface ILeutenantGeneral extends IPrivate, ISoldier {
    void addPrivate(Private pr);
}
