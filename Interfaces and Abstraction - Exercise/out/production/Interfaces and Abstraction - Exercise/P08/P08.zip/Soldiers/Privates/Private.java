package P08.Soldiers.Privates;

import P08.Soldiers.ISoldier;
import P08.Soldiers.Soldier;

public class Private extends Soldier implements ISoldier, IPrivate {
    private Double salary;

    public Private(String id, String firstName, String lastName, Double salary) {
        super(id, firstName, lastName);
        this.salary = salary;
    }

    @Override
    public String getID() {
        return super.getID();
    }

    @Override
    public String getFirstName() {
        return super.getFirstName();
    }

    @Override
    public String getLastName() {
        return super.getLastName();
    }

    @Override
    public Double getSalary() {
        return this.salary;
    }

    @Override
    public String toString() {
        return super.toString() + String.format("Salary: %.2f", this.salary);
    }
}
