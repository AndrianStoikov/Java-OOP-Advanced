package P08.Soldiers.Privates.SpecialisedSoldiers;

import P08.Repairs.Repair;
import P08.Soldiers.ISoldier;
import P08.Soldiers.Privates.IPrivate;

import java.util.ArrayList;
import java.util.List;

public class Engineer extends SpecialisedSoldier implements IEngineeer, ISpecialisedSoldier, IPrivate, ISoldier {
    private List<Repair> repairs;

    public Engineer(String id, String firstName, String lastName, Double salary, String corps) {
        super(id, firstName, lastName, salary, corps);
        this.repairs = new ArrayList<>();
    }

    private String getRepairsToString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Repairs:").append(System.lineSeparator());
        for (Repair repair : this.repairs) {
            sb.append("  ").append(repair.toString()).append(System.lineSeparator());
        }

        return sb.toString().trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(System.lineSeparator());
        sb.append(this.getRepairsToString());
        return sb.toString();
    }

    @Override
    public void addPart(Repair part) {
        this.repairs.add(part);
    }
}
