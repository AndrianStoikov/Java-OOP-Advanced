package P08.Soldiers.Privates.SpecialisedSoldiers;

import P08.Soldiers.ISoldier;
import P08.Soldiers.Privates.IPrivate;
import P08.Soldiers.Privates.Private;

public class SpecialisedSoldier extends Private implements ISoldier, IPrivate, ISpecialisedSoldier {
    private String corps;

    public SpecialisedSoldier(String id, String firstName, String lastName, Double salary, String corps) {
        super(id, firstName, lastName, salary);
        this.setCorps(corps);
    }

    private void setCorps(String corps) {
        if (corps.equals("Airforces") || corps.equals("Marines")) {
            this.corps = corps;
            return;
        }

        throw new IllegalArgumentException("Invalid crops parsed");
    }

    @Override
    public String getID() {
        return super.getID();
    }

    @Override
    public String getFirstName() {
        return super.getFirstName();
    }

    @Override
    public String getLastName() {
        return super.getLastName();
    }

    @Override
    public Double getSalary() {
        return super.getSalary();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(System.lineSeparator());
        sb.append("Corps: ").append(this.corps);
        return sb.toString();
    }
}
