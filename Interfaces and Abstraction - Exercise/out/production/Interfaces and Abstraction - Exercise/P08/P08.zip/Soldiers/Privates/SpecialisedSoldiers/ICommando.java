package P08.Soldiers.Privates.SpecialisedSoldiers;


import P08.Missions.Mission;

public interface ICommando extends ISpecialisedSoldier{
    void addMission(Mission mission);
}
