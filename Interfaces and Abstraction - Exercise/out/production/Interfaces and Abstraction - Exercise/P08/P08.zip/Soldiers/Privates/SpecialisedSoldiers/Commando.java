package P08.Soldiers.Privates.SpecialisedSoldiers;

import P08.Missions.Mission;
import P08.Soldiers.ISoldier;
import P08.Soldiers.Privates.IPrivate;

import java.util.ArrayList;
import java.util.List;

public class Commando extends SpecialisedSoldier implements ICommando, ISpecialisedSoldier, IPrivate, ISoldier {
    private List<Mission> missions;

    public Commando(String id, String firstName, String lastName, Double salary, String corps) {
        super(id, firstName, lastName, salary, corps);
        this.missions = new ArrayList<>();
    }

    private String getMissionsToString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Missions:").append(System.lineSeparator());
        for (Mission mission : this.missions) {
            sb.append("  ").append(mission.toString()).append(System.lineSeparator());
        }

        return sb.toString().trim();
    }

    @Override
    public void addMission(Mission mission) {
        this.missions.add(mission);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(System.lineSeparator());
        sb.append(this.getMissionsToString());
        return sb.toString();
    }
}
