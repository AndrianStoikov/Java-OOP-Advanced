package P08.Soldiers.Privates.SpecialisedSoldiers;

import P08.Repairs.Repair;

public interface IEngineeer extends ISpecialisedSoldier {
    void addPart(Repair part);
}
