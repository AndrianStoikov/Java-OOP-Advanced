package P08.Soldiers.Privates.LeutenantGenerals;

import P08.Soldiers.ISoldier;
import P08.Soldiers.Privates.IPrivate;
import P08.Soldiers.Privates.Private;

import java.util.ArrayList;
import java.util.List;

public class LeutenantGeneral extends Private implements ISoldier, IPrivate, ILeutenantGeneral {
    private List<Private> underCommand;

    public LeutenantGeneral(String id, String firstName, String lastName, Double salary) {
        super(id, firstName, lastName, salary);
        this.underCommand = new ArrayList<>();
    }

    private String getPrivatesToString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Privates:").append(System.lineSeparator());
        for (Private soldier : this.underCommand) {
            sb.append("  ").append(soldier.toString()).append(System.lineSeparator());
        }

        return sb.toString().trim();
    }

    @Override
    public String getID() {
        return super.getID();
    }

    @Override
    public String getFirstName() {
        return super.getFirstName();
    }

    @Override
    public String getLastName() {
        return super.getLastName();
    }

    @Override
    public Double getSalary() {
        return super.getSalary();
    }

    @Override
    public void addPrivate(Private pr) {
        this.underCommand.add(pr);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(System.lineSeparator());
        sb.append(this.getPrivatesToString());
        return sb.toString();
    }
}
