package P09;

import java.util.ArrayList;
import java.util.List;

public class AddRemoveCollection implements Addable, Removeable {
    private List<String> collection;

    public AddRemoveCollection() {
        this.collection = new ArrayList<>();
    }

    @Override
    public Integer add(String item) {
        this.collection.add(0, item);
        return 0;
    }

    @Override
    public String remove() {
        return this.collection.remove(this.collection.size() - 1);
    }
}
