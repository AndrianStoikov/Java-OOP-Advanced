package P09;

/**
 * Created by Andrian on 16.3.2017 г..
 */
public interface Removeable {
    String remove();
}
