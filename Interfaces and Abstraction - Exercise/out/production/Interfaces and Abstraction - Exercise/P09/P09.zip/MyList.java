package P09;

import java.util.ArrayList;
import java.util.List;

public class MyList implements Addable, Removeable {
    private List<String> collection;

    public MyList() {
        this.collection = new ArrayList<>(1);
    }
    @Override
    public Integer add(String item) {
        this.collection.add(0, item);
        return 0;
    }

    @Override
    public String remove() {
        return this.collection.remove(0);
    }

    public Integer used() {
        return this.collection.size();
    }
}
