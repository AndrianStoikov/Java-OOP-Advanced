package P09;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader Console = new BufferedReader(new InputStreamReader(System.in));

        String[] elements = Console.readLine().split(" ");
        int n = Integer.parseInt(Console.readLine());

        AddCollection addCollection = new AddCollection();
        AddRemoveCollection addRemoveCollection =new AddRemoveCollection();
        MyList myList = new MyList();

        for (int i = 0; i < elements.length; i++) {
            System.out.print(addCollection.add(elements[i])  + " ") ;
        }
        System.out.println();

        for (int i = 0; i < elements.length; i++) {
            System.out.print(addRemoveCollection.add(elements[i]) + " ");
        }
        System.out.println();

        for (int i = 0; i < elements.length; i++) {
            System.out.print(myList.add(elements[i]) + " ");
        }
        System.out.println();

        for (int i = 0; i < n; i++) {
            System.out.print(addRemoveCollection.remove() + " ");
        }
        System.out.println();

        for (int i = 0; i < n; i++) {
            System.out.print(myList.remove() + " ");
        }
    }
}
