package P09;

import java.util.ArrayList;
import java.util.List;

public class AddCollection implements Addable {
    private List<String> collection;

    public AddCollection() {
        this.collection = new ArrayList<>(1);
    }

    @Override
    public Integer add(String item) {
        this.collection.add(item);
        return this.collection.size() - 1;
    }
}
