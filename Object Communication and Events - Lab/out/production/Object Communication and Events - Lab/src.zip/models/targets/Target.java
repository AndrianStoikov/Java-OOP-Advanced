package models.targets;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}