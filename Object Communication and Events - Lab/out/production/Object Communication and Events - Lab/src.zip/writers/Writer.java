package writers;

public interface Writer {
    void println(String message);
}
