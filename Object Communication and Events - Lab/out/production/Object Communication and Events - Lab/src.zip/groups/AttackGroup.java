package groups;

import models.attackers.Attacker;
import models.targets.Target;

/**
 * Created by Andrian on 12.4.2017 г..
 */
public interface AttackGroup {
    void addMember(Attacker attacker);

    void groupTarget(Target target);

    void groupAttack();
}
