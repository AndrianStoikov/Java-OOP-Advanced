package logger;

import writers.Writer;

public class CombatLogger extends Logger {

    private Writer writer;
    private Handler handler;

    public CombatLogger(Writer writer) {
        this.writer = writer;
    }

    @Override
    public void handle(LogType type, String message) {
        if (type == LogType.MAGIC || type == LogType.ATTACK) {
            this.writer.println(String.format("%s: %s", type, message));
        } else if (this.handler != null)
            this.handler.handle(type, message);
    }

    @Override
    public void setSuccessor(Handler logger) {
        this.handler = logger;
    }
}
