package logger;

public class Logger implements Handler {
    @Override
    public void handle(LogType type, String message) {

    }

    @Override
    public void setSuccessor(Handler logger) {

    }

}
