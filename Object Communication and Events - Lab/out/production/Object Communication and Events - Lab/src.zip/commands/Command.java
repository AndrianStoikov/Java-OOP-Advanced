package commands;

/**
 * Created by Andrian on 12.4.2017 г..
 */
public interface Command {
    void execute();
}
