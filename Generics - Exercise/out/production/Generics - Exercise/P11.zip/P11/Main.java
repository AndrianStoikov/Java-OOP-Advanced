package P11;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@SuppressWarnings("ALL")
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader Console = new BufferedReader(new InputStreamReader(System.in));

        String[] strings = Console.readLine().split(" ");

        Threeuple<String, String, String> tuple1 = new Threeuple<>(strings[0] + " " + strings[1], strings[2], strings[3]);
        System.out.println(tuple1);


        strings = Console.readLine().split(" ");
        String name = strings[0];
        Integer vals = Integer.valueOf(strings[1]);

        Threeuple<String, Integer, String> tuple2 = new Threeuple<>(name, vals, strings[2]);
        System.out.println(tuple2);

        strings = Console.readLine().split(" ");
        name = strings[0];
        Double aDouble = Double.valueOf(strings[1]);

        Threeuple<String, Double, String> tuple3 = new Threeuple<>(name, aDouble, strings[2]);
        System.out.println(tuple3);
    }
}
