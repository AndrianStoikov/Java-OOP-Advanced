package P08;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    private static Manager manager = new Manager();

    public static void main(String[] args) throws IOException {
        BufferedReader Console = new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(Console.readLine());

        for (int i = 0; i < n; i++) {
            String[] cmdArgs = Console.readLine().split("\\s+");

            try {
                execCommand(cmdArgs);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid Operation!");
            }
        }
    }

    private static void execCommand(String[] cmdArgs) {
        switch (cmdArgs[0]) {
            case "Create": {
                if (cmdArgs[1].equals("Pet")) {
                    manager.createPet(
                            cmdArgs[2],
                            Integer.parseInt(cmdArgs[3]),
                            cmdArgs[4]);
                } else {
                    manager.createClinic(
                            cmdArgs[2],
                            Integer.parseInt(cmdArgs[3])
                    );
                }
            }
            break;
            case "Add": {
                System.out.println(manager.add(cmdArgs[1], cmdArgs[2]));
            }
            break;
            case "Release": {
                System.out.println(manager.release(cmdArgs[1]));
            }
            break;
            case "HasEmptyRooms": {
                System.out.println(manager.hasEmptyRooms(cmdArgs[1]));
            }
            break;
            case "Print": {
                if (cmdArgs.length == 3)
                    System.out.println(manager.print(cmdArgs[1], Integer.parseInt(cmdArgs[2])));
                else System.out.println(manager.print(cmdArgs[1]));
            }
            break;
        }
    }
}
