package P08;

import java.util.HashMap;

public class Manager {

    private HashMap<String, Clinic> clinics;
    private HashMap<String, Pet> pets;

    public Manager() {
        this.clinics = new HashMap<>();
        this.pets = new HashMap<>();
    }

    public void createPet(String name, int age, String kind) {
        Pet p = new Pet(name, age, kind);
        this.pets.put(name, p);
    }

    public void createClinic(String name, int rooms) throws IllegalArgumentException {
        Clinic clinic = new Clinic(name, rooms);
        this.clinics.put(name, clinic);
    }

    public boolean add(String petName, String clinicName) {
        return  this.clinics.get(clinicName).addPet(this.pets.get(petName));
    }

    public boolean release(String clinicName) {
        return  this.clinics.get(clinicName).release();
    }

    public boolean hasEmptyRooms(String clinicName) {
        return this.clinics.get(clinicName).hasEmptyRooms();
    }

    public String print(String clinicName) {
        return this.clinics.get(clinicName).toString();
    }

    public String print(String clinicName,  int room) {
        return this.clinics.get(clinicName).printRoom(room);
    }
}
