package P08;

public class Clinic {
    private String name;
    private Room[] rooms;
    private int index;
    private int indexIncreaser;

    public Clinic(String name, int size) {
        this.name = name;
        this.setRooms(size);
        this.setIndex(size);
        this.indexIncreaser = 0;
    }

    private void setRooms(int size) throws IllegalArgumentException {
        if (size % 2 == 0)
            throw new IllegalArgumentException("Rooms cannot be odd number");

        this.rooms = new Room[size];
        for (int i = 0; i < size; i++) {
            rooms[i] = new Room();
        }
    }

    private void setIndex(int index) {
        Double indResult = getIndex(index);
        this.index = indResult.intValue();
    }

    private double getIndex(int index) {
        if (index == 1)
            return 0;
        return Math.ceil((double) index / 2);
    }

    public boolean hasEmptyRooms() {
        for (Room room : rooms) {
            if (room.isEmpty())
                return true;
        }

        return false;
    }

    public boolean addPet(Pet p) {
        while (!this.rooms[this.index].isEmpty()) {
            this.indexIncreaser++;

            Double ind = this.getIndex(this.rooms.length);
            if (this.index < this.rooms.length / 2) {
                this.index = ind.intValue() + indexIncreaser;
            } else
                this.index = ind.intValue() - indexIncreaser;

            if (this.index == this.rooms.length || this.index < 0) {
                this.index = 0;
                return false;
            }

        }


        this.rooms[index].addPet(p);
        return true;
    }

    public boolean release() {
        Double indAsDouble = this.getIndex(this.rooms.length);
        int ind = indAsDouble.intValue();

        for (int i = ind; i < this.rooms.length; i++) {
            if (!this.rooms[i].isEmpty()) {
                this.rooms[i].release();
                return true;
            }
        }

        for (int i = ind; i >= 0; i--) {
            if (!this.rooms[i].isEmpty()) {
                this.rooms[i].release();
                return true;
            }
        }

        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Room room : rooms) {
            sb.append(room.toString()).append(System.lineSeparator());
        }

        return sb.toString().trim();
    }

    public String printRoom(int room) {
        return this.rooms[room].toString();
    }


}
