package P08;

public class Room {
    private boolean isEmpty;
    private Pet pet;

    public Room() {
        this.isEmpty = true;
    }

    public boolean isEmpty() {
        return this.isEmpty;
    }

    public void addPet(Pet p) {
        this.pet = p;
        this.isEmpty = false;
    }

    public void release() {
        this.isEmpty = true;
        this.pet = null;
    }

    @Override
    public String toString() {
        if(this.isEmpty)
            return "Room empty";

        return this.pet.toString();
    }
}
